
import pandas as pd
def load_csv(path_file):
  return pd.read_csv(path_file)
